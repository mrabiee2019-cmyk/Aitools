# قوانین Proguard/R8 - در فاز انتشار نهایی تکمیل می‌شود
-keep class com.example.aitoolbox.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class org.json.** { *; }
-dontwarn com.google.mlkit.**
-keep class com.google.mlkit.** { *; }
-keep class androidx.room.** { *; }
