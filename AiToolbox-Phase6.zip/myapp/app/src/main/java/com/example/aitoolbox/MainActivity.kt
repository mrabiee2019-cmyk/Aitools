package com.example.aitoolbox

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.aitoolbox.ui.ai.AiFragment
import com.example.aitoolbox.ui.browser.BrowserFragment
import com.example.aitoolbox.ui.data.DataFragment
import com.example.aitoolbox.ui.media.MediaFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * اکتیویتی اصلی اپ.
 * وظیفه‌ی این کلاس فقط نگه‌داری نوار ناوبری پایین و سوییچ بین فرگمنت‌هاست.
 * هر تب (مرورگر، هوش مصنوعی، رسانه، داده‌ها) یک فرگمنت مستقل دارد
 * تا توسعه‌ی هر بخش در فازهای بعدی بدون تأثیر روی بقیه انجام شود.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_nav)

        // در اولین اجرا، تب مرورگر را به صورت پیش‌فرض نشان می‌دهیم
        if (savedInstanceState == null) {
            showFragment(BrowserFragment())
        }

        bottomNav.setOnItemSelectedListener { item ->
            val fragment: Fragment = when (item.itemId) {
                R.id.nav_browser -> BrowserFragment()
                R.id.nav_ai -> AiFragment()
                R.id.nav_media -> MediaFragment()
                R.id.nav_data -> DataFragment()
                else -> BrowserFragment()
            }
            showFragment(fragment)
            true
        }
    }

    private fun showFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }
}
