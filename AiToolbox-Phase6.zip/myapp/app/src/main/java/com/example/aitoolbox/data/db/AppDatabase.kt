package com.example.aitoolbox.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

/**
 * تبدیل enum مربوط به منبع داده به/از String برای ذخیره در دیتابیس
 * (Room به‌صورت پیش‌فرض نمی‌تواند enum را مستقیم ذخیره کند).
 */
class Converters {
    @TypeConverter
    fun fromDataSource(source: DataSource): String = source.name

    @TypeConverter
    fun toDataSource(value: String): DataSource = DataSource.valueOf(value)
}

@Database(
    entities = [DataRecord::class, ImprovementRequest::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun dataRecordDao(): DataRecordDao
    abstract fun improvementRequestDao(): ImprovementRequestDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        /** الگوی Singleton استاندارد برای دیتابیس - فقط یک نمونه در کل اپ */
        fun getInstance(context: Context): AppDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "aitoolbox_database"
                ).build().also { instance = it }
            }
        }
    }
}
