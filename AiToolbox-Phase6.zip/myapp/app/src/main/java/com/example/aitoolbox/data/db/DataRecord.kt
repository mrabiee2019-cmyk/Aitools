package com.example.aitoolbox.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * منبع اصلی یک رکورد داده — مشخص می‌کند این داده از کجا وارد دیتابیس شده.
 */
enum class DataSource {
    MANUAL,   // تایپ دستی توسط کاربر
    MEDIA_OCR, // استخراج‌شده از عکس/ویدیو با OCR
    AI_OUTPUT  // استخراج‌شده از پاسخ هوش مصنوعی
}

/**
 * یک رکورد داده در دیتابیس.
 *
 * هر رکورد می‌تواند یک یا چند عدد داشته باشد (numbersCsv، رشته‌ای از اعداد
 * جدا‌شده با کاما، چون یک ورودی واحد - مثلاً یک عکس OCR شده - ممکن است
 * چند عدد همزمان داشته باشد). متن خام هم برای مرجع نگه‌داری می‌شود.
 *
 * dedupKey برای کمک به موتور تشخیص تکرار استفاده می‌شود: مجموعه‌ی اعداد
 * این رکورد را به یک رشته‌ی نرمال‌شده (مرتب‌شده) تبدیل می‌کند تا تطابق دقیق
 * سریع‌تر قابل بررسی باشد، بدون نیاز به پارس کردن دوباره‌ی numbersCsv در هر بار.
 */
@Entity(tableName = "data_records")
data class DataRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val category: String,

    val source: DataSource,

    /** اعداد استخراج‌شده از این رکورد، جدا‌شده با کاما (مثلاً "12.5,30,7") */
    val numbersCsv: String,

    /** متن کامل/خام ورودی (برای مرجع و نمایش به کاربر) */
    val rawText: String,

    /** زمان ثبت رکورد (میلی‌ثانیه از epoch) - مبنای محاسبه‌ی فاصله‌ی زمانی بین تکرارها */
    val timestampMillis: Long,

    /** کلید نرمال‌شده برای تشخیص سریع تطابق دقیق (اعداد مرتب‌شده، جدا‌شده با |) */
    val dedupKey: String,

    /** در صورتی که این رکورد از یک فایل رسانه‌ای آمده، مسیر آن (برای نمایش پیش‌نمایش) */
    val mediaUriString: String? = null
)
