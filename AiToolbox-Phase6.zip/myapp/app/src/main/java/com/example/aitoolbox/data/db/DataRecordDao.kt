package com.example.aitoolbox.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DataRecordDao {

    @Insert
    suspend fun insert(record: DataRecord): Long

    /** همه‌ی رکوردها، جدیدترین در بالا - برای نمایش لیست کلی */
    @Query("SELECT * FROM data_records ORDER BY timestampMillis DESC")
    fun observeAll(): Flow<List<DataRecord>>

    /** فقط رکوردهای یک دسته‌بندی خاص - برای صفحه‌ی مقایسه */
    @Query("SELECT * FROM data_records WHERE category = :category ORDER BY timestampMillis ASC")
    suspend fun getByCategory(category: String): List<DataRecord>

    /** لیست یکتای همه‌ی دسته‌بندی‌های موجود - برای پر کردن Dropdown فیلتر */
    @Query("SELECT DISTINCT category FROM data_records ORDER BY category ASC")
    fun observeCategories(): Flow<List<String>>

    @Delete
    suspend fun delete(record: DataRecord)

    @Query("DELETE FROM data_records WHERE id = :recordId")
    suspend fun deleteById(recordId: Long)
}
