package com.example.aitoolbox.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * یک درخواست بهبود/ویژگی جدید که کاربر به زبان فارسی توضیح داده است.
 *
 * این درخواست‌ها مستقیماً توسط اپ اجرا نمی‌شوند (یک اپ نصب‌شده نمی‌تواند
 * خودش را در لحظه بازنویسی و دوباره نصب کند). در عوض:
 * 1. کاربر متن درخواست را اینجا می‌نویسد و ذخیره می‌کند
 * 2. می‌تواند همان متن را به یکی از سرویس‌های هوش مصنوعی متصل بفرستد
 *    تا توضیح فنی/پیشنهاد پیاده‌سازی بگیرد (aiSuggestion)
 * 3. در نشست بعدی با توسعه‌دهنده (یا چت Claude)، این لیست به‌عنوان
 *    راهنمای دقیق برای نوشتن کد واقعی و ساخت نسخه‌ی جدید اپ استفاده می‌شود
 */
@Entity(tableName = "improvement_requests")
data class ImprovementRequest(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    /** متن درخواست به زبان فارسی، نوشته‌شده توسط کاربر */
    val requestText: String,

    /** پیشنهاد/توضیح فنی که هوش مصنوعی (اختیاری) برای این درخواست داده است */
    val aiSuggestion: String? = null,

    /** وضعیت: در انتظار بررسی، یا علامت‌خورده به‌عنوان انجام‌شده در نسخه‌ی بعدی */
    val isResolved: Boolean = false,

    val timestampMillis: Long
)
