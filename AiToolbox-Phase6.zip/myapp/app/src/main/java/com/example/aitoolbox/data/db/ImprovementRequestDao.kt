package com.example.aitoolbox.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ImprovementRequestDao {

    @Insert
    suspend fun insert(request: ImprovementRequest): Long

    @Update
    suspend fun update(request: ImprovementRequest)

    @Query("SELECT * FROM improvement_requests ORDER BY timestampMillis DESC")
    fun observeAll(): Flow<List<ImprovementRequest>>

    @Delete
    suspend fun delete(request: ImprovementRequest)
}
