package com.example.aitoolbox.data.db

import java.util.Locale

/**
 * ابزار کمکی برای استخراج اعداد از یک متن خام.
 * این تابع در هر سه مسیر ورودی استفاده می‌شود:
 * - وقتی کاربر مستقیم عدد/متن تایپ می‌کند
 * - وقتی متن پاسخ هوش مصنوعی ذخیره می‌شود
 * - وقتی نتیجه‌ی OCR یک عکس استخراج می‌شود
 *
 * اعداد اعشاری (با نقطه) و منفی هم پشتیبانی می‌شوند.
 * اعداد فارسی/عربی (۰-۹) هم قبل از پارس به اعداد لاتین تبدیل می‌شوند
 * تا OCR یا تایپ فارسی هم درست کار کند.
 */
object NumberExtractor {

    private val persianDigits = "۰۱۲۳۴۵۶۷۸۹"
    private val arabicDigits = "٠١٢٣٤٥٦٧٨٩"

    /** تبدیل ارقام فارسی/عربی موجود در متن به ارقام لاتین معادل */
    private fun normalizeDigits(text: String): String {
        val builder = StringBuilder(text.length)
        for (ch in text) {
            val persianIndex = persianDigits.indexOf(ch)
            val arabicIndex = arabicDigits.indexOf(ch)
            when {
                persianIndex >= 0 -> builder.append(persianIndex)
                arabicIndex >= 0 -> builder.append(arabicIndex)
                else -> builder.append(ch)
            }
        }
        return builder.toString()
    }

    /** الگوی Regex برای یافتن اعداد صحیح/اعشاری/منفی در متن */
    private val numberRegex = Regex("""-?\d+(?:\.\d+)?""")

    /**
     * استخراج همه‌ی اعداد موجود در یک متن، به ترتیب ظاهرشدن.
     * بازمی‌گرداند: لیستی از مقادیر Double.
     */
    fun extractNumbers(rawText: String): List<Double> {
        val normalized = normalizeDigits(rawText)
        return numberRegex.findAll(normalized)
            .mapNotNull { it.value.toDoubleOrNull() }
            .toList()
    }

    /** تبدیل لیست اعداد به یک رشته‌ی CSV برای ذخیره در دیتابیس */
    fun toCsv(numbers: List<Double>): String =
        numbers.joinToString(",") { formatNumber(it) }

    /** پارس کردن رشته‌ی CSV ذخیره‌شده در دیتابیس به لیست اعداد */
    fun fromCsv(csv: String): List<Double> {
        if (csv.isBlank()) return emptyList()
        return csv.split(",").mapNotNull { it.trim().toDoubleOrNull() }
    }

    /** ساخت کلید نرمال‌شده برای تشخیص سریع تطابق دقیق (مرتب‌شده، بدون توجه به ترتیب ورود) */
    fun buildDedupKey(numbers: List<Double>): String =
        numbers.sorted().joinToString("|") { formatNumber(it) }

    private fun formatNumber(value: Double): String {
        // اگر عدد صحیح است بدون اعشار نمایش بده (مثلاً 30 نه 30.0)
        return if (value == Math.floor(value) && !value.isInfinite()) {
            value.toLong().toString()
        } else {
            String.format(Locale.US, "%.4f", value).trimEnd('0').trimEnd('.')
        }
    }
}
