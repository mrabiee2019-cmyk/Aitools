package com.example.aitoolbox.data.pattern

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

/**
 * استخراج متن از یک عکس با استفاده از Google ML Kit Text Recognition.
 *
 * این پردازش کاملاً روی خود گوشی (on-device) انجام می‌شود: بدون تماس
 * اینترنتی، بدون هزینه‌ی سرویس ابری، و بدون ارسال تصویر به جایی.
 * مدل لازم در صورت نیاز در همان دفعه‌ی اول به‌صورت خودکار دانلود می‌شود
 * (چند مگابایت، فقط یک‌بار).
 */
object OcrHelper {

    /**
     * متن کامل تشخیص داده‌شده در عکس را برمی‌گرداند.
     * اگر تصویر متن قابل تشخیصی نداشته باشد، رشته‌ی خالی برمی‌گردد.
     */
    suspend fun extractTextFromImage(context: Context, uri: Uri): String {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        return try {
            val image = InputImage.fromFilePath(context, uri)
            val result = recognizer.process(image).await()
            result.text
        } catch (e: Exception) {
            ""
        } finally {
            recognizer.close()
        }
    }
}
