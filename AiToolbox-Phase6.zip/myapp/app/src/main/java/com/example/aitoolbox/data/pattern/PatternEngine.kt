package com.example.aitoolbox.data.pattern

import com.example.aitoolbox.data.db.DataRecord
import com.example.aitoolbox.data.db.NumberExtractor
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * موتور تشخیص الگو در داده‌های عددی ذخیره‌شده.
 *
 * سه نوع بررسی مستقل انجام می‌شود (طبق درخواست: «هر دو» تعریف شباهت):
 *
 * 1. EXACT_REPEAT — رکوردهایی که دقیقاً همان مجموعه‌ی اعداد را دارند
 *    (با استفاده از dedupKey که در NumberExtractor ساخته شده).
 *
 * 2. SIMILAR_TREND — رکوردهایی که اعداد متفاوتی دارند اما «شکل» نوسانشان
 *    شبیه‌هم است. این با ضریب همبستگی پیرسون (Pearson correlation) سنجیده
 *    می‌شود: اگر وقتی عدد اول دنباله‌ی A بالا می‌رود، عدد اول دنباله‌ی B هم
 *    بالا می‌رود (نسبت به میانگین خودش)، همبستگی بالا می‌شود؛ این معیار
 *    استاندارد و دقیق برای «روند مشابه» در آمار است، نه یک تخمین ظاهری.
 *
 * 3. REGULAR_CYCLE — بررسی می‌کند آیا فاصله‌ی زمانی بین رکوردهای متوالی
 *    یک دسته‌بندی، یک الگوی منظم/تکرارشونده دارد (مثلاً تقریباً هر ۷ روز
 *    یک‌بار) با محاسبه‌ی انحراف نسبی فاصله‌ها از میانگینشان.
 */
object PatternEngine {

    /** حداقل تشابه (۰ تا ۱) برای اینکه دو دنباله «روند مشابه» در نظر گرفته شوند */
    private const val TREND_SIMILARITY_THRESHOLD = 0.85

    /** حداکثر انحراف نسبی مجاز فاصله‌های زمانی تا «سیکل منظم» در نظر گرفته شود */
    private const val CYCLE_VARIATION_THRESHOLD = 0.20

    /**
     * تحلیل کامل یک دسته‌بندی: همه‌ی رکوردهای آن دسته را می‌گیرد و
     * هر سه نوع یافته را برمی‌گرداند.
     *
     * @param records رکوردهای یک دسته‌بندی، باید از قبل بر اساس timestampMillis صعودی مرتب باشند
     */
    fun analyzeCategory(category: String, records: List<DataRecord>): List<PatternFinding> {
        if (records.size < 2) return emptyList()

        val findings = mutableListOf<PatternFinding>()
        findings += findExactRepeats(category, records)
        findings += findSimilarTrends(category, records)
        findCycleRegularity(category, records)?.let { findings += it }
        return findings
    }

    // ---------- ۱. تطابق دقیق ----------

    private fun findExactRepeats(category: String, records: List<DataRecord>): List<PatternFinding> {
        val groups = records
            .filter { it.dedupKey.isNotBlank() }
            .groupBy { it.dedupKey }
            .filter { (_, group) -> group.size >= 2 }

        return groups.map { (key, group) ->
            val numbersPreview = key.replace("|", ", ")
            PatternFinding(
                type = MatchType.EXACT_REPEAT,
                category = category,
                involvedRecords = group,
                description = "همان مجموعه‌ی اعداد ($numbersPreview) دقیقاً ${group.size} بار در دسته‌بندی «$category» تکرار شده است.",
                confidence = 1.0
            )
        }
    }

    // ---------- ۲. شباهت روند (Pearson correlation) ----------

    private fun findSimilarTrends(category: String, records: List<DataRecord>): List<PatternFinding> {
        // فقط رکوردهایی که حداقل ۲ عدد دارند می‌توانند «روند» داشته باشند
        val sequences = records.mapNotNull { record ->
            val numbers = NumberExtractor.fromCsv(record.numbersCsv)
            if (numbers.size >= 2) record to numbers else null
        }

        if (sequences.size < 2) return emptyList()

        val findings = mutableListOf<PatternFinding>()
        val alreadyMatched = mutableSetOf<Long>()

        for (i in sequences.indices) {
            for (j in i + 1 until sequences.size) {
                val (recordA, seqA) = sequences[i]
                val (recordB, seqB) = sequences[j]

                // اعداد عیناً یکسان را اینجا دوباره گزارش نمی‌کنیم (در EXACT_REPEAT آمده)
                if (recordA.dedupKey == recordB.dedupKey) continue

                val correlation = pearsonCorrelation(seqA, seqB) ?: continue
                if (abs(correlation) >= TREND_SIMILARITY_THRESHOLD) {
                    // برای جلوگیری از تکرار بیش از حد گزارش، هر رکورد فقط یک‌بار در یک یافته شرکت می‌کند
                    if (recordA.id in alreadyMatched && recordB.id in alreadyMatched) continue

                    val direction = if (correlation > 0) "هم‌جهت" else "معکوس"
                    findings += PatternFinding(
                        type = MatchType.SIMILAR_TREND,
                        category = category,
                        involvedRecords = listOf(recordA, recordB),
                        description = "روند نوسان دو مجموعه‌ی عددی در دسته‌بندی «$category» $direction و بسیار شبیه‌هم است " +
                            "(میزان شباهت: ${(abs(correlation) * 100).toInt()}٪)، حتی اگر اعداد دقیقاً یکسان نباشند.",
                        confidence = abs(correlation)
                    )
                    alreadyMatched += recordA.id
                    alreadyMatched += recordB.id
                }
            }
        }
        return findings
    }

    /**
     * ضریب همبستگی پیرسون بین دو دنباله‌ی عددی.
     * نتیجه بین -1 (رابطه‌ی کاملاً معکوس) تا +1 (رابطه‌ی کاملاً هم‌جهت) است؛
     * 0 یعنی هیچ رابطه‌ی خطی‌ای وجود ندارد.
     *
     * اگر طول دو دنباله متفاوت باشد، فقط طول مشترک (کوتاه‌تر) مقایسه می‌شود.
     * اگر هرکدام واریانس صفر داشته باشند (همه‌ی اعداد یکسان)، محاسبه معتبر نیست و null برمی‌گردد.
     */
    private fun pearsonCorrelation(a: List<Double>, b: List<Double>): Double? {
        val n = minOf(a.size, b.size)
        if (n < 2) return null

        val x = a.take(n)
        val y = b.take(n)
        val meanX = x.average()
        val meanY = y.average()

        var covariance = 0.0
        var varianceX = 0.0
        var varianceY = 0.0

        for (k in 0 until n) {
            val dx = x[k] - meanX
            val dy = y[k] - meanY
            covariance += dx * dy
            varianceX += dx * dx
            varianceY += dy * dy
        }

        if (varianceX == 0.0 || varianceY == 0.0) return null

        return covariance / sqrt(varianceX * varianceY)
    }

    // ---------- ۳. سیکل زمانی (فاصله‌ی منظم بین تکرارها) ----------

    private fun findCycleRegularity(category: String, records: List<DataRecord>): PatternFinding? {
        if (records.size < 3) return null // برای تشخیص «الگو»، حداقل ۲ فاصله (۳ نقطه) لازم است

        val sortedByTime = records.sortedBy { it.timestampMillis }
        val gaps = sortedByTime.zipWithNext { a, b -> (b.timestampMillis - a.timestampMillis).toDouble() }
            .filter { it > 0 }

        if (gaps.size < 2) return null

        val meanGap = gaps.average()
        if (meanGap <= 0) return null

        // انحراف معیار فاصله‌ها، نسبت به میانگین (ضریب تغییرات / Coefficient of Variation)
        val variance = gaps.sumOf { (it - meanGap) * (it - meanGap) } / gaps.size
        val stdDev = sqrt(variance)
        val coefficientOfVariation = stdDev / meanGap

        if (coefficientOfVariation > CYCLE_VARIATION_THRESHOLD) return null

        val averageDays = meanGap / (1000.0 * 60 * 60 * 24)
        val regularity = (1.0 - coefficientOfVariation).coerceIn(0.0, 1.0)

        val periodLabel = formatPeriod(averageDays)

        return PatternFinding(
            type = MatchType.REGULAR_CYCLE,
            category = category,
            involvedRecords = sortedByTime,
            description = "رکوردهای دسته‌بندی «$category» با یک فاصله‌ی زمانی نسبتاً منظم (تقریباً $periodLabel یک‌بار) تکرار می‌شوند " +
                "(ثبات الگو: ${(regularity * 100).toInt()}٪).",
            confidence = regularity
        )
    }

    private fun formatPeriod(days: Double): String {
        return when {
            days < 1.0 -> "${(days * 24).toInt()} ساعت"
            days < 2.0 -> "هر روز"
            days < 8.0 -> "${days.toInt()} روز"
            days < 35.0 -> "${(days / 7).toInt()} هفته"
            else -> "${(days / 30).toInt()} ماه"
        }
    }
}
