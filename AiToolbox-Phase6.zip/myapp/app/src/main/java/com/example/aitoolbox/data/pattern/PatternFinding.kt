package com.example.aitoolbox.data.pattern

import com.example.aitoolbox.data.db.DataRecord

/**
 * نوع تطابق پیدا‌شده بین دو یا چند رکورد.
 */
enum class MatchType {
    /** همان اعداد، عیناً تکرار شده‌اند */
    EXACT_REPEAT,

    /** اعداد متفاوت‌اند اما روند/شکل نوسانشان مشابه است (correlation بالا) */
    SIMILAR_TREND,

    /** فاصله‌ی زمانی بین وقوع رکوردهای یک دسته، منظم/تکرارشونده است (سیکل زمانی) */
    REGULAR_CYCLE
}

/**
 * یک یافته‌ی موتور تشخیص الگو - یک یا چند رکورد که با هم رابطه‌ی خاصی دارند.
 */
data class PatternFinding(
    val type: MatchType,
    val category: String,
    val involvedRecords: List<DataRecord>,
    /** توضیح آماده برای نمایش به کاربر، به زبان فارسی */
    val description: String,
    /** عدد بین ۰ تا ۱ - هرچه بالاتر، شباهت/قطعیت بیشتر */
    val confidence: Double
)
