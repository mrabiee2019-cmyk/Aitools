package com.example.aitoolbox.ui.ai

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.aitoolbox.R
import com.example.aitoolbox.databinding.FragmentAiBinding
import com.example.aitoolbox.util.SecureKeyStore
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * فرگمنت تب «هوش مصنوعی».
 *
 * کاربر می‌تواند:
 * - از بین چند سرویس هوش مصنوعی (OpenAI, Anthropic, Gemini, Groq, OpenRouter) یکی را انتخاب کند
 * - با دکمه‌ی تنظیمات (⚙️) کلید API هر سرویس را وارد یا حذف کند
 * - سوال خود را تایپ کرده و پاسخ مدل را در همان صفحه ببیند
 *
 * هر سرویس کلید جداگانه‌ی خودش را دارد و کلیدها به‌صورت رمزنگاری‌شده
 * روی گوشی ذخیره می‌شوند (نگاه کنید به SecureKeyStore).
 */
class AiFragment : Fragment() {

    private var _binding: FragmentAiBinding? = null
    private val binding get() = _binding!!

    private lateinit var keyStore: SecureKeyStore
    private var selectedProvider: AiProvider = AiProviderRegistry.all.first()

    private lateinit var voiceInputHelper: VoiceInputHelper

    /** درخواست مجوز میکروفون مخصوص ورودی صوتی این تب */
    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startVoiceInput()
        else toast(getString(R.string.ai_voice_permission_denied))
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAiBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        keyStore = SecureKeyStore(requireContext())
        voiceInputHelper = VoiceInputHelper(requireContext())

        setupProviderDropdown()
        updateKeyStatusText()

        binding.btnProviderSettings.setOnClickListener { showApiKeyDialog() }
        binding.btnSendPrompt.setOnClickListener { onSendClicked() }
        binding.btnVoiceInput.setOnClickListener { requestMicThenListen() }
    }

    /** پُر کردن Dropdown با نام نمایشی همه‌ی سرویس‌های موجود */
    private fun setupProviderDropdown() {
        val names = AiProviderRegistry.all.map { it.displayName }
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, names)
        binding.dropdownProvider.setAdapter(adapter)
        binding.dropdownProvider.setText(selectedProvider.displayName, false)

        binding.dropdownProvider.setOnItemClickListener { _, _, position, _ ->
            selectedProvider = AiProviderRegistry.all[position]
            updateKeyStatusText()
        }
    }

    /** نمایش وضعیت فعلی کلید (تنظیم‌شده یا نه) زیر نوار انتخاب سرویس */
    private fun updateKeyStatusText() {
        val hasKey = keyStore.hasKey(selectedProvider.id)
        binding.textKeyStatus.text = if (hasKey) {
            getString(R.string.ai_key_set, selectedProvider.displayName)
        } else {
            getString(R.string.ai_key_not_set, selectedProvider.displayName)
        }
    }

    /** نمایش دیالوگ ورود/حذف کلید API برای سرویس انتخاب‌شده‌ی فعلی */
    private fun showApiKeyDialog() {
        val input = EditText(requireContext()).apply {
            hint = getString(R.string.ai_dialog_hint)
            setText(keyStore.getKey(selectedProvider.id).orEmpty())
            setSingleLine(true)
        }

        val container = android.widget.LinearLayout(requireContext()).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            val padding = (16 * resources.displayMetrics.density).toInt()
            setPadding(padding, padding / 2, padding, 0)
            addView(input)
        }

        MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.ai_dialog_title, selectedProvider.displayName))
            .setMessage(getString(R.string.ai_dialog_get_key_hint))
            .setView(container)
            .setPositiveButton(R.string.ai_dialog_save) { _, _ ->
                val key = input.text?.toString()?.trim().orEmpty()
                if (key.isNotEmpty()) {
                    keyStore.saveKey(selectedProvider.id, key)
                    updateKeyStatusText()
                }
            }
            .setNegativeButton(R.string.ai_dialog_cancel, null)
            .setNeutralButton(R.string.ai_dialog_clear) { _, _ ->
                keyStore.clearKey(selectedProvider.id)
                updateKeyStatusText()
            }
            .show()
    }

    /** اعتبارسنجی ورودی و شروع فراخوانی سرویس هوش مصنوعی */
    private fun onSendClicked() {
        val prompt = binding.editPrompt.text?.toString()?.trim().orEmpty()
        if (prompt.isEmpty()) {
            toast(getString(R.string.ai_empty_prompt_toast))
            return
        }

        val apiKey = keyStore.getKey(selectedProvider.id)
        if (apiKey.isNullOrBlank()) {
            toast(getString(R.string.ai_missing_key_toast))
            showApiKeyDialog()
            return
        }

        sendPromptToProvider(apiKey, prompt)
    }

    // ---------- ورودی صوتی (تشخیص گفتار) ----------

    /** بررسی مجوز میکروفون و در صورت نیاز درخواست آن، سپس شروع گوش‌دادن */
    private fun requestMicThenListen() {
        val hasPermission = androidx.core.content.ContextCompat.checkSelfPermission(
            requireContext(), android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            startVoiceInput()
        } else {
            micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
        }
    }

    /**
     * شروع تشخیص گفتار. متن شناسایی‌شده مستقیماً در فیلد پرامپت قرار می‌گیرد
     * و سپس به‌طور خودکار به سرویس هوش مصنوعی انتخاب‌شده ارسال می‌شود —
     * یعنی کاربر فقط با صحبت کردن می‌تواند سوال بپرسد و پاسخ بگیرد.
     */
    private fun startVoiceInput() {
        voiceInputHelper.startListening(object : VoiceInputHelper.Listener {
            override fun onListeningStarted() {
                binding.textListeningStatus.visibility = View.VISIBLE
            }

            override fun onResult(text: String) {
                binding.editPrompt.setText(text)
                toast(getString(R.string.ai_voice_auto_send_hint))

                // ارسال خودکار به سرویس هوش مصنوعی فعلی، مشروط بر اینکه کلید API تنظیم شده باشد
                val apiKey = keyStore.getKey(selectedProvider.id)
                if (apiKey.isNullOrBlank()) {
                    toast(getString(R.string.ai_missing_key_toast))
                    showApiKeyDialog()
                } else {
                    sendPromptToProvider(apiKey, text)
                }
            }

            override fun onError(message: String) {
                toast(message)
            }

            override fun onListeningEnded() {
                binding.textListeningStatus.visibility = View.GONE
            }
        })
    }

    /**
     * فراخوانی سرویس هوش مصنوعی در یک Coroutine.
     * شبکه روی Dispatchers.IO اجرا می‌شود تا UI Thread مسدود نشود؛
     * نتیجه دوباره به Main Thread برمی‌گردد تا بتوان UI را به‌روزرسانی کرد.
     */
    private fun sendPromptToProvider(apiKey: String, prompt: String) {
        binding.progressAi.visibility = View.VISIBLE
        binding.textResponse.text = getString(R.string.ai_thinking)
        binding.btnSendPrompt.isEnabled = false

        val provider = selectedProvider

        viewLifecycleOwner.lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                provider.sendPrompt(apiKey, prompt)
            }

            binding.progressAi.visibility = View.GONE
            binding.btnSendPrompt.isEnabled = true

            when (result) {
                is AiResult.Success -> {
                    binding.textResponse.text = result.text
                    com.example.aitoolbox.util.LastAiResponseHolder.update(result.text)
                }
                is AiResult.Failure -> binding.textResponse.text = result.message
            }
        }
    }

    private fun toast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        voiceInputHelper.stopListening()
        _binding = null
    }
}
