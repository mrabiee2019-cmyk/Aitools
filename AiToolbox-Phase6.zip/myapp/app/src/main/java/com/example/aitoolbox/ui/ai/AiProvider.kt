package com.example.aitoolbox.ui.ai

/**
 * نتیجه‌ی فراخوانی یک سرویس هوش مصنوعی.
 */
sealed class AiResult {
    data class Success(val text: String) : AiResult()
    data class Failure(val message: String) : AiResult()
}

/**
 * اینترفیس مشترکی که همه‌ی سرویس‌های هوش مصنوعی باید پیاده‌سازی کنند.
 * این الگو (Strategy Pattern) اجازه می‌دهد افزودن سرویس جدید در آینده
 * فقط نیاز به یک کلاس جدید داشته باشد، بدون تغییر در بقیه‌ی برنامه.
 */
interface AiProvider {
    /** شناسه‌ی یکتا برای ذخیره‌ی API Key (مثلاً "openai", "anthropic") */
    val id: String

    /** نام نمایشی در رابط کاربری */
    val displayName: String

    /** آدرس صفحه‌ای که کاربر می‌تواند از آن API Key بگیرد (برای راهنمایی در UI) */
    val apiKeyHelpUrl: String

    /**
     * ارسال یک پرامپت متنی به سرویس و دریافت پاسخ.
     * این تابع suspend است و باید در یک Coroutine (مثلاً Dispatchers.IO) اجرا شود.
     */
    suspend fun sendPrompt(apiKey: String, prompt: String): AiResult
}
