package com.example.aitoolbox.ui.ai

/**
 * لیست مرکزی همه‌ی سرویس‌های هوش مصنوعی پشتیبانی‌شده.
 * برای افزودن یک سرویس جدید در آینده، کافی است:
 * 1. یک کلاس جدید که AiProvider را پیاده‌سازی می‌کند بسازید
 * 2. آن را به لیست زیر اضافه کنید
 * هیچ تغییر دیگری در بقیه‌ی برنامه لازم نیست.
 */
object AiProviderRegistry {
    val all: List<AiProvider> = listOf(
        OpenAiProvider(),
        AnthropicProvider(),
        GeminiProvider(),
        GroqProvider(),
        OpenRouterProvider()
    )

    fun findById(id: String): AiProvider? = all.find { it.id == id }
}
