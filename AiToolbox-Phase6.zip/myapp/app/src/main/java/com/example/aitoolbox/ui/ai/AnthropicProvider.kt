package com.example.aitoolbox.ui.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * اتصال به Anthropic Claude API از طریق endpoint استاندارد /v1/messages.
 * مدل پیش‌فرض claude-sonnet-4-6 است (نسخه‌ی متوازن از نظر سرعت و هزینه).
 *
 * نکات فرمت خاص Anthropic نسبت به OpenAI:
 * - هدر آن x-api-key است نه Authorization: Bearer
 * - هدر anthropic-version الزامی است
 * - فیلد max_tokens الزامی است (OpenAI آن را اختیاری می‌داند)
 * - متن پاسخ در content[0].text قرار دارد، نه choices[0].message.content
 */
class AnthropicProvider : AiProvider {

    override val id = "anthropic"
    override val displayName = "Anthropic (Claude)"
    override val apiKeyHelpUrl = "https://console.anthropic.com/settings/keys"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    override suspend fun sendPrompt(apiKey: String, prompt: String): AiResult {
        return try {
            val messages = JSONArray().put(
                JSONObject().put("role", "user").put("content", prompt)
            )
            val body = JSONObject()
                .put("model", "claude-sonnet-4-6")
                .put("max_tokens", 1024)
                .put("messages", messages)
                .toString()
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return AiResult.Failure(extractErrorMessage(rawBody, response.code))
                }
                val json = JSONObject(rawBody)
                val text = json.getJSONArray("content")
                    .getJSONObject(0)
                    .getString("text")
                AiResult.Success(text.trim())
            }
        } catch (e: Exception) {
            AiResult.Failure("خطا در اتصال به Anthropic: ${e.message}")
        }
    }

    private fun extractErrorMessage(rawBody: String, code: Int): String {
        return try {
            JSONObject(rawBody).getJSONObject("error").getString("message")
        } catch (_: Exception) {
            "خطای سرویس (کد $code)"
        }
    }
}
