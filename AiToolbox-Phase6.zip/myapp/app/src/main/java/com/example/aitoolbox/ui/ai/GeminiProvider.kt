package com.example.aitoolbox.ui.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * اتصال به Google Gemini API از طریق endpoint استاندارد generateContent.
 * مدل پیش‌فرض gemini-2.5-flash است (سریع و رایگان در حد قابل قبولی).
 *
 * نکات فرمت خاص Gemini نسبت به OpenAI/Anthropic:
 * - آدرس شامل نام مدل است: /models/{model}:generateContent
 * - کلید API به‌صورت هدر x-goog-api-key ارسال می‌شود
 * - بدنه‌ی درخواست از contents/parts استفاده می‌کند، نه messages
 * - متن پاسخ در candidates[0].content.parts[0].text قرار دارد
 */
class GeminiProvider : AiProvider {

    override val id = "gemini"
    override val displayName = "Google (Gemini)"
    override val apiKeyHelpUrl = "https://aistudio.google.com/apikey"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    override suspend fun sendPrompt(apiKey: String, prompt: String): AiResult {
        return try {
            val parts = JSONArray().put(JSONObject().put("text", prompt))
            val contents = JSONArray().put(
                JSONObject().put("role", "user").put("parts", parts)
            )
            val body = JSONObject()
                .put("contents", contents)
                .toString()
                .toRequestBody("application/json".toMediaType())

            val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
                "gemini-2.5-flash:generateContent"

            val request = Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", apiKey)
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return AiResult.Failure(extractErrorMessage(rawBody, response.code))
                }
                val json = JSONObject(rawBody)
                val text = json.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                AiResult.Success(text.trim())
            }
        } catch (e: Exception) {
            AiResult.Failure("خطا در اتصال به Gemini: ${e.message}")
        }
    }

    private fun extractErrorMessage(rawBody: String, code: Int): String {
        return try {
            JSONObject(rawBody).getJSONObject("error").getString("message")
        } catch (_: Exception) {
            "خطای سرویس (کد $code)"
        }
    }
}
