package com.example.aitoolbox.ui.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * اتصال به Groq API — یک سرویس بسیار سریع (به‌خاطر سخت‌افزار مخصوص LPU)
 * که از همان فرمت درخواست/پاسخ OpenAI پیروی می‌کند (/v1/chat/completions).
 * مدل پیش‌فرض llama-3.3-70b-versatile است.
 */
class GroqProvider : AiProvider {

    override val id = "groq"
    override val displayName = "Groq (Llama - سریع)"
    override val apiKeyHelpUrl = "https://console.groq.com/keys"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    override suspend fun sendPrompt(apiKey: String, prompt: String): AiResult {
        return try {
            val messages = JSONArray().put(
                JSONObject().put("role", "user").put("content", prompt)
            )
            val body = JSONObject()
                .put("model", "llama-3.3-70b-versatile")
                .put("messages", messages)
                .toString()
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("https://api.groq.com/openai/v1/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return AiResult.Failure(extractErrorMessage(rawBody, response.code))
                }
                val json = JSONObject(rawBody)
                val text = json.getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                AiResult.Success(text.trim())
            }
        } catch (e: Exception) {
            AiResult.Failure("خطا در اتصال به Groq: ${e.message}")
        }
    }

    private fun extractErrorMessage(rawBody: String, code: Int): String {
        return try {
            JSONObject(rawBody).getJSONObject("error").getString("message")
        } catch (_: Exception) {
            "خطای سرویس (کد $code)"
        }
    }
}
