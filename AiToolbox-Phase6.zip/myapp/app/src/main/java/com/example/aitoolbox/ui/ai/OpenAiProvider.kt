package com.example.aitoolbox.ui.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * اتصال به OpenAI API از طریق endpoint استاندارد /v1/chat/completions.
 * مدل پیش‌فرض gpt-4o-mini است (سریع و کم‌هزینه)؛ کاربر می‌تواند بعداً
 * این مقدار را در تنظیمات پیشرفته تغییر دهد.
 */
class OpenAiProvider : AiProvider {

    override val id = "openai"
    override val displayName = "OpenAI (ChatGPT)"
    override val apiKeyHelpUrl = "https://platform.openai.com/api-keys"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    override suspend fun sendPrompt(apiKey: String, prompt: String): AiResult {
        return try {
            val messages = JSONArray().put(
                JSONObject().put("role", "user").put("content", prompt)
            )
            val body = JSONObject()
                .put("model", "gpt-4o-mini")
                .put("messages", messages)
                .toString()
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return AiResult.Failure(extractErrorMessage(rawBody, response.code))
                }
                val json = JSONObject(rawBody)
                val text = json.getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                AiResult.Success(text.trim())
            }
        } catch (e: Exception) {
            AiResult.Failure("خطا در اتصال به OpenAI: ${e.message}")
        }
    }

    private fun extractErrorMessage(rawBody: String, code: Int): String {
        return try {
            JSONObject(rawBody).getJSONObject("error").getString("message")
        } catch (_: Exception) {
            "خطای سرویس (کد $code)"
        }
    }
}
