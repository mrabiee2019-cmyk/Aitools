package com.example.aitoolbox.ui.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * کلاس کمکی برای تشخیص گفتار (Speech-to-Text) با استفاده از API بومی اندروید.
 *
 * این کلاس کاملاً رایگان و بدون نیاز به سرویس بیرونی یا API Key کار می‌کند —
 * از همان موتور تشخیص گفتار سیستم (معمولاً Google) استفاده می‌کند.
 *
 * نکته: SpeechRecognizer باید فقط روی Main Thread استفاده شود.
 */
class VoiceInputHelper(private val context: Context) {

    interface Listener {
        fun onListeningStarted()
        fun onResult(text: String)
        fun onError(message: String)
        fun onListeningEnded()
    }

    private var recognizer: SpeechRecognizer? = null

    /** بررسی می‌کند که آیا دستگاه اصلاً قابلیت تشخیص گفتار دارد یا نه */
    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    /** شروع گوش‌دادن و تشخیص گفتار فارسی/انگلیسی (بر اساس زبان سیستم) */
    fun startListening(listener: Listener) {
        if (!isAvailable()) {
            listener.onError(context.getString(com.example.aitoolbox.R.string.ai_voice_not_available))
            return
        }

        stopListening() // اطمینان از پاک شدن نمونه‌ی قبلی قبل از شروع جدید

        val speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = speechRecognizer

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // زبان سیستم را به‌صورت پیش‌فرض استفاده می‌کنیم (مثلاً fa-IR یا en-US)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toString())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listener.onListeningStarted()
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull().orEmpty()
                if (text.isNotBlank()) {
                    listener.onResult(text)
                } else {
                    listener.onError(context.getString(com.example.aitoolbox.R.string.ai_voice_error))
                }
                listener.onListeningEnded()
            }

            override fun onError(error: Int) {
                listener.onError(context.getString(com.example.aitoolbox.R.string.ai_voice_error))
                listener.onListeningEnded()
            }

            override fun onEndOfSpeech() {
                listener.onListeningEnded()
            }

            // رویدادهای زیر برای منطق فعلی لازم نیستند اما باید پیاده‌سازی شوند
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer.startListening(intent)
    }

    /** توقف و آزادسازی منابع تشخیص گفتار */
    fun stopListening() {
        recognizer?.destroy()
        recognizer = null
    }
}
