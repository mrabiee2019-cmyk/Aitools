package com.example.aitoolbox.ui.browser

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import com.example.aitoolbox.R
import com.example.aitoolbox.databinding.FragmentBrowserBinding

/**
 * فرگمنت مرورگر داخلی اپ.
 *
 * این بخش یک WebView واقعی است که:
 * - با نوار آدرس بالا، کاربر می‌تواند هر سایتی را وارد و باز کند
 * - دکمه‌های قبلی/بعدی/رفرش تاریخچه‌ی مرورگر را کنترل می‌کنند
 * - نوار پیشرفت بارگذاری صفحه را نشان می‌دهد
 * - دکمه Back گوشی، در صورت وجود تاریخچه در WebView، یک صفحه به عقب برمی‌گردد
 *   (به‌جای بستن اپ یا خروج از تب)
 */
class BrowserFragment : Fragment() {

    private var _binding: FragmentBrowserBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBrowserBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val webView = binding.webView

        // فعال‌سازی تنظیمات لازم برای اینکه سایت‌های مدرن درست نمایش داده شوند
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            // اجازه به محتوای مخلوط (برخی سایت‌ها بخشی از منابع را از http بارمی‌کنند)
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                binding.progressBar.visibility = View.GONE
                // به‌روزرسانی نوار آدرس با آدرس واقعی صفحه‌ی بازشده
                binding.editUrl.setText(url)
                updateNavButtons()
            }
        }

        webView.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (newProgress in 1..99) {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.progressBar.progress = newProgress
                } else {
                    binding.progressBar.visibility = View.GONE
                }
            }
        }

        // بارگذاری صفحه‌ی پیش‌فرض در اولین اجرا
        if (savedInstanceState == null) {
            loadUrlFromInput(getString(R.string.browser_default_url))
            binding.editUrl.setText(getString(R.string.browser_default_url))
        }

        // دکمه «برو»: آدرس وارد شده توسط کاربر را باز می‌کند
        binding.btnGo.setOnClickListener {
            val typed = binding.editUrl.text?.toString().orEmpty()
            loadUrlFromInput(typed)
        }

        // فشردن Enter/Go روی کیبورد هم معادل دکمه «برو» است
        binding.editUrl.setOnEditorActionListener { _, _, _ ->
            val typed = binding.editUrl.text?.toString().orEmpty()
            loadUrlFromInput(typed)
            true
        }

        binding.btnBack.setOnClickListener {
            if (webView.canGoBack()) webView.goBack()
        }
        binding.btnForward.setOnClickListener {
            if (webView.canGoForward()) webView.goForward()
        }
        binding.btnReload.setOnClickListener {
            webView.reload()
        }

        // دکمه Back فیزیکی/جستی گوشی: اول تاریخچه‌ی مرورگر را خالی کن، بعد اجازه‌ی خروج بده
        requireActivity().onBackPressedDispatcher.addCallback(
            viewLifecycleOwner,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        isEnabled = false
                        requireActivity().onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        )
    }

    /**
     * آدرس وارد شده توسط کاربر را اعتبارسنجی و بارگذاری می‌کند.
     * اگر کاربر فقط یک کلمه (نه یک URL کامل) وارد کند، آن را به‌عنوان جستجوی گوگل تفسیر می‌کند.
     */
    private fun loadUrlFromInput(rawInput: String) {
        val input = rawInput.trim()
        if (input.isEmpty()) return

        val finalUrl = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=${android.net.Uri.encode(input)}"
        }

        binding.webView.loadUrl(finalUrl)
    }

    private fun updateNavButtons() {
        binding.btnBack.isEnabled = binding.webView.canGoBack()
        binding.btnForward.isEnabled = binding.webView.canGoForward()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // آزاد کردن منابع WebView برای جلوگیری از نشت حافظه
        binding.webView.destroy()
        _binding = null
    }
}
