package com.example.aitoolbox.ui.data

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aitoolbox.R
import com.example.aitoolbox.data.db.AppDatabase
import com.example.aitoolbox.data.db.DataRecord
import com.example.aitoolbox.data.db.DataSource
import com.example.aitoolbox.data.db.ImprovementRequest
import com.example.aitoolbox.data.db.NumberExtractor
import com.example.aitoolbox.data.pattern.MatchType
import com.example.aitoolbox.data.pattern.OcrHelper
import com.example.aitoolbox.data.pattern.PatternEngine
import com.example.aitoolbox.data.pattern.PatternFinding
import com.example.aitoolbox.databinding.FragmentDataBinding
import com.example.aitoolbox.ui.ai.AiProviderRegistry
import com.example.aitoolbox.ui.ai.AiResult
import com.example.aitoolbox.util.LastAiResponseHolder
import com.example.aitoolbox.util.SecureKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * فرگمنت تب «داده‌ها».
 *
 * این تب چهار مسئولیت اصلی دارد:
 *
 * 1. **افزودن داده** از سه منبع: تایپ دستی، OCR روی عکس (با ML Kit، کاملاً
 *    آفلاین)، یا آخرین پاسخ دریافتی از تب هوش مصنوعی.
 *
 * 2. **تحلیل و مقایسه**: با انتخاب یک دسته‌بندی، موتور PatternEngine روی
 *    همه‌ی رکوردهای آن دسته اجرا می‌شود و هر سه نوع یافته (تکرار دقیق،
 *    شباهت روند، سیکل زمانی منظم) به فارسی نمایش داده می‌شود.
 *
 * 3. **مدیریت رکوردها**: نمایش و حذف رکوردهای ذخیره‌شده.
 *
 * 4. **درخواست بهبود**: کاربر می‌تواند به فارسی بنویسد چه ویژگی یا تغییری
 *    می‌خواهد. این متن ذخیره می‌شود و در صورت تمایل می‌تواند فوراً برای
 *    «نظر فنی» به یکی از سرویس‌های هوش مصنوعی متصل ارسال شود. این درخواست‌ها
 *    به‌صورت زنده در اپ اجرا نمی‌شوند (یک اپ نصب‌شده نمی‌تواند خودش را در لحظه
 *    بازنویسی/کامپایل/نصب کند)، بلکه به‌عنوان فهرست دقیق برای ساخت نسخه‌ی بعدی
 *    در یک نشست توسعه‌ی واقعی استفاده می‌شوند.
 */
class DataFragment : Fragment() {

    private var _binding: FragmentDataBinding? = null
    private val binding get() = _binding!!

    private lateinit var database: AppDatabase
    private lateinit var keyStore: SecureKeyStore

    private lateinit var recordAdapter: DataRecordAdapter
    private lateinit var improvementAdapter: ImprovementAdapter

    private var allCategories: List<String> = emptyList()
    private var selectedCategoryForAnalysis: String? = null

    /** نتیجه‌ی انتخاب عکس برای OCR */
    private val pickImageForOcrLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) runOcrAndSave(uri)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDataBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        database = AppDatabase.getInstance(requireContext())
        keyStore = SecureKeyStore(requireContext())

        setupRecordsList()
        setupImprovementsList()
        observeDatabase()

        binding.btnSaveManual.setOnClickListener { saveManualEntry() }
        binding.btnAddFromImage.setOnClickListener { pickImageForOcrLauncher.launch("image/*") }
        binding.btnAddFromAi.setOnClickListener { saveFromLastAiResponse() }
        binding.btnAnalyze.setOnClickListener { runAnalysis() }
        binding.btnSaveImprovement.setOnClickListener { saveImprovementRequest(askAi = false) }
        binding.btnAskAiImprovement.setOnClickListener { saveImprovementRequest(askAi = true) }
    }

    private fun setupRecordsList() {
        recordAdapter = DataRecordAdapter(emptyList()) { record ->
            viewLifecycleOwner.lifecycleScope.launch {
                database.dataRecordDao().delete(record)
            }
        }
        binding.recyclerRecords.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerRecords.adapter = recordAdapter
    }

    private fun setupImprovementsList() {
        improvementAdapter = ImprovementAdapter(emptyList())
        binding.recyclerImprovements.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerImprovements.adapter = improvementAdapter
    }

    /** اتصال به Flowهای دیتابیس - هر تغییری در دیتابیس خودکار در UI منعکس می‌شود */
    private fun observeDatabase() {
        viewLifecycleOwner.lifecycleScope.launch {
            database.dataRecordDao().observeAll().collect { records ->
                recordAdapter.submitList(records)
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            database.dataRecordDao().observeCategories().collect { categories ->
                allCategories = categories
                setupCategoryDropdown(categories)
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            database.improvementRequestDao().observeAll().collect { requests ->
                improvementAdapter.submitList(requests)
            }
        }
    }

    private fun setupCategoryDropdown(categories: List<String>) {
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, categories)
        binding.dropdownCategoryFilter.setAdapter(adapter)
        binding.dropdownCategoryFilter.setOnItemClickListener { _, _, position, _ ->
            selectedCategoryForAnalysis = categories[position]
        }
    }

    // ---------- افزودن داده: مسیر دستی ----------

    private fun saveManualEntry() {
        val category = binding.editCategory.text?.toString()?.trim().orEmpty()
        val value = binding.editManualValue.text?.toString()?.trim().orEmpty()

        if (category.isEmpty()) {
            toast(getString(R.string.data_no_category_toast))
            return
        }
        if (value.isEmpty()) {
            toast(getString(R.string.data_no_value_toast))
            return
        }

        saveRecord(category = category, rawText = value, source = DataSource.MANUAL, mediaUri = null)
        binding.editManualValue.setText("")
        toast(getString(R.string.data_saved_toast))
    }

    // ---------- افزودن داده: مسیر OCR از عکس ----------

    private fun runOcrAndSave(uri: android.net.Uri) {
        val category = binding.editCategory.text?.toString()?.trim().orEmpty()
        if (category.isEmpty()) {
            toast(getString(R.string.data_no_category_toast))
            return
        }

        binding.progressOcr.visibility = View.VISIBLE

        viewLifecycleOwner.lifecycleScope.launch {
            val extractedText = withContext(Dispatchers.Default) {
                OcrHelper.extractTextFromImage(requireContext(), uri)
            }
            binding.progressOcr.visibility = View.GONE

            val numbers = NumberExtractor.extractNumbers(extractedText)
            if (numbers.isEmpty()) {
                toast(getString(R.string.data_ocr_no_numbers))
                return@launch
            }

            saveRecord(
                category = category,
                rawText = extractedText.ifBlank { NumberExtractor.toCsv(numbers) },
                source = DataSource.MEDIA_OCR,
                mediaUri = uri.toString()
            )
            toast(getString(R.string.data_saved_toast))
        }
    }

    // ---------- افزودن داده: مسیر آخرین پاسخ هوش مصنوعی ----------

    private fun saveFromLastAiResponse() {
        val category = binding.editCategory.text?.toString()?.trim().orEmpty()
        if (category.isEmpty()) {
            toast(getString(R.string.data_no_category_toast))
            return
        }

        val lastResponse = LastAiResponseHolder.lastResponseText
        if (lastResponse.isNullOrBlank()) {
            toast(getString(R.string.data_no_ai_response_toast))
            return
        }

        saveRecord(category = category, rawText = lastResponse, source = DataSource.AI_OUTPUT, mediaUri = null)
        toast(getString(R.string.data_saved_toast))
    }

    // ---------- ذخیره‌ی مشترک ----------

    /**
     * تابع مشترک ذخیره‌سازی برای هر سه منبع.
     * اعداد از متن خام استخراج می‌شوند، CSV و dedupKey ساخته می‌شود،
     * و رکورد نهایی در دیتابیس درج می‌شود.
     */
    private fun saveRecord(category: String, rawText: String, source: DataSource, mediaUri: String?) {
        val numbers = NumberExtractor.extractNumbers(rawText)
        val record = DataRecord(
            category = category,
            source = source,
            numbersCsv = NumberExtractor.toCsv(numbers),
            rawText = rawText,
            timestampMillis = System.currentTimeMillis(),
            dedupKey = NumberExtractor.buildDedupKey(numbers),
            mediaUriString = mediaUri
        )
        viewLifecycleOwner.lifecycleScope.launch {
            database.dataRecordDao().insert(record)
        }
    }

    // ---------- تحلیل و مقایسه ----------

    private fun runAnalysis() {
        val category = selectedCategoryForAnalysis
        if (category.isNullOrBlank()) {
            toast(getString(R.string.data_no_category_for_analysis))
            return
        }

        viewLifecycleOwner.lifecycleScope.launch {
            val records = withContext(Dispatchers.IO) {
                database.dataRecordDao().getByCategory(category)
            }

            if (records.size < 2) {
                binding.textFindings.text = getString(R.string.data_not_enough_records, records.size)
                return@launch
            }

            val findings = withContext(Dispatchers.Default) {
                PatternEngine.analyzeCategory(category, records)
            }

            renderFindings(findings)
        }
    }

    private fun renderFindings(findings: List<PatternFinding>) {
        if (findings.isEmpty()) {
            binding.textFindings.text = getString(R.string.data_no_findings)
            return
        }

        val builder = StringBuilder(getString(R.string.data_findings_header))
        findings.forEachIndexed { index, finding ->
            val icon = when (finding.type) {
                MatchType.EXACT_REPEAT -> "🔁"
                MatchType.SIMILAR_TREND -> "📈"
                MatchType.REGULAR_CYCLE -> "⏱"
            }
            builder.append("\n$icon ${index + 1}. ${finding.description}\n")
        }
        binding.textFindings.text = builder.toString().trim()
    }

    // ---------- درخواست بهبود ----------

    private fun saveImprovementRequest(askAi: Boolean) {
        val text = binding.editImprovement.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) {
            toast(getString(R.string.data_no_improvement_text))
            return
        }

        viewLifecycleOwner.lifecycleScope.launch {
            val request = ImprovementRequest(
                requestText = text,
                timestampMillis = System.currentTimeMillis()
            )
            val newId = database.improvementRequestDao().insert(request)
            binding.editImprovement.setText("")
            toast(getString(R.string.data_improvement_saved))

            if (askAi) {
                askAiForSuggestion(newId, text)
            }
        }
    }

    /**
     * ارسال متن درخواست بهبود به یکی از سرویس‌های هوش مصنوعی متصل (اولین
     * سرویسی که کلید آن تنظیم شده است) تا یک توضیح فنی/پیشنهاد پیاده‌سازی
     * بگیریم. این پاسخ صرفاً برای راهنمایی ذخیره می‌شود و کدی به‌صورت خودکار
     * در اپ تغییر نمی‌دهد.
     */
    private fun askAiForSuggestion(requestId: Long, requestText: String) {
        val provider = AiProviderRegistry.all.firstOrNull { keyStore.hasKey(it.id) }
        if (provider == null) {
            toast("برای این قابلیت، اول یک کلید API در تب «هوش مصنوعی» تنظیم کنید")
            return
        }
        val apiKey = keyStore.getKey(provider.id) ?: return

        toast(getString(R.string.data_asking_ai))

        val prompt = "این یک درخواست بهبود برای یک اپ اندرویدی است. به فارسی و خلاصه " +
            "توضیح بده این ویژگی چطور باید طراحی/پیاده‌سازی شود:\n\n$requestText"

        viewLifecycleOwner.lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { provider.sendPrompt(apiKey, prompt) }
            if (result is AiResult.Success) {
                val updated = ImprovementRequest(
                    id = requestId,
                    requestText = requestText,
                    aiSuggestion = result.text,
                    isResolved = false,
                    timestampMillis = System.currentTimeMillis()
                )
                database.improvementRequestDao().update(updated)
            }
        }
    }

    private fun toast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
