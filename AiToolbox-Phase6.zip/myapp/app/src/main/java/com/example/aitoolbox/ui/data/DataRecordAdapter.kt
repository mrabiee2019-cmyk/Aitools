package com.example.aitoolbox.ui.data

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.aitoolbox.R
import com.example.aitoolbox.data.db.DataRecord
import com.example.aitoolbox.data.db.DataSource
import com.google.android.material.button.MaterialButton
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * آداپتور نمایش لیست رکوردهای ذخیره‌شده در تب داده‌ها.
 * هر ردیف، دسته‌بندی، متن خام، منبع (دستی/OCR/AI) و زمان ثبت را نشان می‌دهد.
 */
class DataRecordAdapter(
    private var items: List<DataRecord>,
    private val onDeleteClick: (DataRecord) -> Unit
) : RecyclerView.Adapter<DataRecordAdapter.RecordViewHolder>() {

    inner class RecordViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val category: TextView = view.findViewById(R.id.record_category)
        val text: TextView = view.findViewById(R.id.record_text)
        val meta: TextView = view.findViewById(R.id.record_meta)
        val deleteBtn: MaterialButton = view.findViewById(R.id.record_delete_btn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): RecordViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_data_record, parent, false)
        return RecordViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecordViewHolder, position: Int) {
        val record = items[position]
        holder.category.text = record.category
        holder.text.text = record.rawText.ifBlank { record.numbersCsv }

        val sourceLabel = when (record.source) {
            DataSource.MANUAL -> "دستی"
            DataSource.MEDIA_OCR -> "از عکس (OCR)"
            DataSource.AI_OUTPUT -> "از هوش مصنوعی"
        }
        val dateLabel = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
            .format(Date(record.timestampMillis))
        holder.meta.text = "$sourceLabel  •  $dateLabel"

        holder.deleteBtn.setOnClickListener { onDeleteClick(record) }
    }

    override fun getItemCount(): Int = items.size

    /** جایگزینی کامل لیست (مثلاً وقتی Flow از دیتابیس مقدار جدید می‌دهد) */
    fun submitList(newItems: List<DataRecord>) {
        items = newItems
        notifyDataSetChanged()
    }
}
