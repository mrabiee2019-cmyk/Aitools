package com.example.aitoolbox.ui.data

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.aitoolbox.R
import com.example.aitoolbox.data.db.ImprovementRequest

/**
 * آداپتور نمایش لیست درخواست‌های بهبود ذخیره‌شده توسط کاربر.
 * اگر هوش مصنوعی نظری برای یک درخواست داده باشد، آن هم زیر متن اصلی نشان داده می‌شود.
 */
class ImprovementAdapter(
    private var items: List<ImprovementRequest>
) : RecyclerView.Adapter<ImprovementAdapter.ImprovementViewHolder>() {

    inner class ImprovementViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val status: TextView = view.findViewById(R.id.improvement_status)
        val text: TextView = view.findViewById(R.id.improvement_text)
        val aiSuggestion: TextView = view.findViewById(R.id.improvement_ai_suggestion)
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ImprovementViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_improvement_request, parent, false)
        return ImprovementViewHolder(view)
    }

    override fun onBindViewHolder(holder: ImprovementViewHolder, position: Int) {
        val item = items[position]
        holder.status.text = holder.itemView.context.getString(
            if (item.isResolved) R.string.data_improvement_resolved else R.string.data_improvement_pending
        )
        holder.text.text = item.requestText

        if (!item.aiSuggestion.isNullOrBlank()) {
            holder.aiSuggestion.visibility = View.VISIBLE
            holder.aiSuggestion.text = "نظر هوش مصنوعی: ${item.aiSuggestion}"
        } else {
            holder.aiSuggestion.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int = items.size

    fun submitList(newItems: List<ImprovementRequest>) {
        items = newItems
        notifyDataSetChanged()
    }
}
