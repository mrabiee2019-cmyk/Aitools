package com.example.aitoolbox.ui.media

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.aitoolbox.R
import com.google.android.material.button.MaterialButton

/**
 * آداپتور ساده برای نمایش فایل‌های ضبط‌شده/انتخاب‌شده در تب رسانه.
 * با کلیک روی دکمه «باز کردن»، فایل با اپلیکیشن پیش‌فرض سیستم باز می‌شود.
 */
class MediaFileAdapter(
    private val items: MutableList<MediaItem>,
    private val onOpenClick: (MediaItem) -> Unit
) : RecyclerView.Adapter<MediaFileAdapter.MediaViewHolder>() {

    inner class MediaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.item_icon)
        val name: TextView = view.findViewById(R.id.item_name)
        val meta: TextView = view.findViewById(R.id.item_meta)
        val openBtn: MaterialButton = view.findViewById(R.id.item_open_btn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): MediaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_media_file, parent, false)
        return MediaViewHolder(view)
    }

    override fun onBindViewHolder(holder: MediaViewHolder, position: Int) {
        val item = items[position]
        holder.name.text = item.displayName
        holder.meta.text = item.sizeLabel

        val iconRes = when (item.type) {
            MediaType.PHOTO -> R.drawable.ic_media
            MediaType.VIDEO -> R.drawable.ic_video
            MediaType.AUDIO -> R.drawable.ic_mic
            MediaType.FILE -> R.drawable.ic_file
        }
        holder.icon.setImageResource(iconRes)

        holder.openBtn.setOnClickListener { onOpenClick(item) }
    }

    override fun getItemCount(): Int = items.size

    /** افزودن یک فایل جدید به ابتدای لیست (جدیدترین در بالا) */
    fun addItem(item: MediaItem) {
        items.add(0, item)
        notifyItemInserted(0)
    }
}
