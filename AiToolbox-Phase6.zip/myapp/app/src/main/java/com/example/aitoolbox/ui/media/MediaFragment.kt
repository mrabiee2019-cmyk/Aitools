package com.example.aitoolbox.ui.media

import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aitoolbox.R
import com.example.aitoolbox.databinding.FragmentMediaBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * فرگمنت تب «رسانه».
 *
 * چهار قابلیت اصلی:
 * 1. گرفتن عکس با دوربین (ذخیره در فایل اپ از طریق FileProvider)
 * 2. ضبط ویدیو با دوربین (با اپ پیش‌فرض دوربین گوشی)
 * 3. ضبط صدا با میکروفون (با MediaRecorder داخلی، بدون نیاز به اپ بیرونی)
 * 4. انتخاب فایل دلخواه از حافظه‌ی گوشی
 *
 * همه‌ی مجوزهای لازم (دوربین، میکروفون، فایل) در زمان اجرا (runtime) درخواست می‌شوند.
 */
class MediaFragment : Fragment() {

    private var _binding: FragmentMediaBinding? = null
    private val binding get() = _binding!!

    // URI فایلی که قراره عکس/ویدیوی دوربین در آن ذخیره شود
    private var pendingCameraUri: Uri? = null

    // برای ضبط صدا با MediaRecorder
    private var mediaRecorder: MediaRecorder? = null
    private var audioOutputFile: File? = null

    private lateinit var fileAdapter: MediaFileAdapter
    private val mediaList = mutableListOf<MediaItem>()

    // ---------- Launcherهای مجوز ----------

    /** درخواست مجوز دوربین، در صورت تایید مستقیماً عکس می‌گیرد */
    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchCameraForPhoto()
        else showPermissionDenied()
    }

    /** درخواست مجوز دوربین برای ویدیو */
    private val cameraPermissionForVideoLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchCameraForVideo()
        else showPermissionDenied()
    }

    /** درخواست مجوز میکروفون برای ضبط صدا */
    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startAudioRecording()
        else showPermissionDenied()
    }

    // ---------- Launcherهای نتیجه ----------

    /** نتیجه‌ی گرفتن عکس با دوربین */
    private val takePhotoLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) {
            binding.imagePreview.visibility = View.VISIBLE
            binding.imagePreview.setImageURI(uri)
            addMediaToList(uri, "photo_${timestamp()}.jpg", MediaType.PHOTO)
            toast(getString(R.string.media_saved_photo))
        }
    }

    /** نتیجه‌ی ضبط ویدیو با دوربین */
    private val takeVideoLauncher = registerForActivityResult(
        ActivityResultContracts.CaptureVideo()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) {
            addMediaToList(uri, "video_${timestamp()}.mp4", MediaType.VIDEO)
            toast(getString(R.string.media_saved_video))
        }
    }

    /** نتیجه‌ی انتخاب فایل دلخواه از حافظه */
    private val pickFileLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val name = queryFileName(uri) ?: "file_${timestamp()}"
            addMediaToList(uri, name, MediaType.FILE)
            toast(getString(R.string.media_saved_file))
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMediaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        fileAdapter = MediaFileAdapter(mediaList) { item -> openMediaItem(item) }
        binding.recyclerFiles.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerFiles.adapter = fileAdapter

        binding.btnTakePhoto.setOnClickListener { requestCameraThenTakePhoto() }
        binding.btnRecordVideo.setOnClickListener { requestCameraThenRecordVideo() }
        binding.btnRecordAudio.setOnClickListener { requestMicThenRecord() }
        binding.btnPickFile.setOnClickListener { pickFileLauncher.launch("*/*") }
        binding.btnStopRecording.setOnClickListener { stopAudioRecording() }
    }

    // ---------- عکس ----------

    private fun requestCameraThenTakePhoto() {
        if (hasPermission(android.Manifest.permission.CAMERA)) {
            launchCameraForPhoto()
        } else {
            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    private fun launchCameraForPhoto() {
        val file = createMediaFile("jpg")
        val uri = FileProvider.getUriForFile(
            requireContext(),
            "${requireContext().packageName}.fileprovider",
            file
        )
        pendingCameraUri = uri
        takePhotoLauncher.launch(uri)
    }

    // ---------- ویدیو ----------

    private fun requestCameraThenRecordVideo() {
        if (hasPermission(android.Manifest.permission.CAMERA)) {
            launchCameraForVideo()
        } else {
            cameraPermissionForVideoLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    private fun launchCameraForVideo() {
        val file = createMediaFile("mp4")
        val uri = FileProvider.getUriForFile(
            requireContext(),
            "${requireContext().packageName}.fileprovider",
            file
        )
        pendingCameraUri = uri
        takeVideoLauncher.launch(uri)
    }

    // ---------- صدا (ضبط داخلی با MediaRecorder) ----------

    private fun requestMicThenRecord() {
        if (hasPermission(android.Manifest.permission.RECORD_AUDIO)) {
            startAudioRecording()
        } else {
            micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startAudioRecording() {
        val file = createMediaFile("m4a")
        audioOutputFile = file

        @Suppress("DEPRECATION")
        val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(requireContext())
        } else {
            MediaRecorder()
        }

        try {
            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            mediaRecorder = recorder
            binding.layoutRecordingStatus.visibility = View.VISIBLE
        } catch (e: Exception) {
            toast("خطا در شروع ضبط صدا: ${e.message}")
        }
    }

    private fun stopAudioRecording() {
        val recorder = mediaRecorder ?: return
        try {
            recorder.stop()
        } catch (_: Exception) {
            // اگر ضبط خیلی کوتاه بوده ممکن است stop خطا بدهد؛ فایل را همچنان بررسی می‌کنیم
        } finally {
            recorder.release()
            mediaRecorder = null
            binding.layoutRecordingStatus.visibility = View.GONE
        }

        val file = audioOutputFile
        if (file != null && file.exists() && file.length() > 0) {
            val uri = FileProvider.getUriForFile(
                requireContext(),
                "${requireContext().packageName}.fileprovider",
                file
            )
            addMediaToList(uri, file.name, MediaType.AUDIO)
            toast(getString(R.string.media_saved_audio))
        }
    }

    // ---------- ابزارهای کمکی مشترک ----------

    private fun hasPermission(permission: String): Boolean {
        return androidx.core.content.ContextCompat.checkSelfPermission(
            requireContext(), permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun showPermissionDenied() {
        toast(getString(R.string.media_permission_denied))
    }

    private fun toast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    private fun timestamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    /** ساخت فایل خام جدید در پوشه‌ی داخلی media اپ، با پسوند مشخص */
    private fun createMediaFile(extension: String): File {
        val mediaDir = File(requireContext().getExternalFilesDir(null), "media")
        if (!mediaDir.exists()) mediaDir.mkdirs()
        return File(mediaDir, "${extension}_${timestamp()}.$extension")
    }

    /** افزودن آیتم جدید به لیست و نمایش بخش‌های مرتبط در UI */
    private fun addMediaToList(uri: Uri, name: String, type: MediaType) {
        val sizeLabel = formatFileSize(uri)
        fileAdapter.addItem(MediaItem(uri, name, type, sizeLabel))
        binding.textFilesTitle.visibility = View.VISIBLE
    }

    private fun formatFileSize(uri: Uri): String {
        return try {
            requireContext().contentResolver.openFileDescriptor(uri, "r")?.use { fd ->
                val bytes = fd.statSize
                when {
                    bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
                    bytes >= 1_000 -> "%.1f KB".format(bytes / 1_000.0)
                    else -> "$bytes B"
                }
            } ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    /** خواندن نام نمایشی یک فایل از روی URI (برای فایل‌های انتخاب‌شده از حافظه) */
    private fun queryFileName(uri: Uri): String? {
        var result: String? = null
        val cursor = requireContext().contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) result = it.getString(index)
            }
        }
        return result
    }

    /** باز کردن فایل با اپلیکیشن پیش‌فرض سیستم (مثلاً پخش‌کننده‌ی ویدیو یا نمایشگر عکس) */
    private fun openMediaItem(item: MediaItem) {
        try {
            val mime = requireContext().contentResolver.getType(item.uri) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(item.uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            toast("امکان باز کردن این فایل وجود ندارد")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mediaRecorder?.release()
        mediaRecorder = null
        _binding = null
    }
}
