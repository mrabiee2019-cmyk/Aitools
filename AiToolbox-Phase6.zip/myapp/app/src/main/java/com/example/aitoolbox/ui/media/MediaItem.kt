package com.example.aitoolbox.ui.media

import android.net.Uri

/**
 * نوع فایل رسانه‌ای برای انتخاب آیکون و رفتار مناسب هنگام باز کردن.
 */
enum class MediaType {
    PHOTO, VIDEO, AUDIO, FILE
}

/**
 * نگه‌دارنده‌ی اطلاعات یک فایل رسانه‌ای که در همین جلسه (session) اپ
 * ضبط یا انتخاب شده است. این لیست فقط در حافظه نگه‌داری می‌شود؛
 * ذخیره‌سازی دائمی در فاز دیتابیس (فاز بعدی) اضافه خواهد شد.
 */
data class MediaItem(
    val uri: Uri,
    val displayName: String,
    val type: MediaType,
    val sizeLabel: String
)
