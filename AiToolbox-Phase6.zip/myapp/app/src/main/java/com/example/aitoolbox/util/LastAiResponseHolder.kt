package com.example.aitoolbox.util

/**
 * نگه‌دارنده‌ی ساده‌ی در حافظه برای «آخرین پاسخ هوش مصنوعی».
 *
 * چرا لازم است: تب «هوش مصنوعی» و تب «داده‌ها» دو فرگمنت جدا هستند و
 * مستقیماً به هم دسترسی ندارند. وقتی کاربر در تب AI پاسخی می‌گیرد و بعد
 * به تب داده‌ها می‌رود تا با دکمه‌ی «افزودن از آخرین پاسخ» آن را ذخیره کند،
 * این Singleton پلی بین آن دو فرگمنت است.
 *
 * این یک حافظه‌ی موقت (در سطح پردازش اپ) است، نه دیتابیس؛ با بسته‌شدن کامل
 * اپ از بین می‌رود (که طبیعی است، چون هدف فقط انتقال لحظه‌ای بین دو تب است).
 */
object LastAiResponseHolder {
    var lastResponseText: String? = null
        private set

    fun update(text: String) {
        lastResponseText = text
    }

    fun clear() {
        lastResponseText = null
    }
}
