package com.example.aitoolbox.util

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * مدیریت ذخیره‌سازی امن API Key های هر سرویس هوش مصنوعی.
 *
 * از EncryptedSharedPreferences استفاده می‌شود تا کلیدها روی دیسک
 * به‌صورت رمزنگاری‌شده ذخیره شوند (نه متن خام)، حتی اگر گوشی روت باشد
 * یا فایل‌های اپ به نحوی استخراج شوند.
 *
 * هیچ کلیدی در کد هاردکد نشده است؛ همه چیز توسط خود کاربر در
 * صفحه‌ی تنظیمات وارد می‌شود.
 */
class SecureKeyStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "ai_provider_keys",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveKey(providerId: String, apiKey: String) {
        prefs.edit().putString(providerId, apiKey).apply()
    }

    fun getKey(providerId: String): String? = prefs.getString(providerId, null)

    fun hasKey(providerId: String): Boolean = !getKey(providerId).isNullOrBlank()

    fun clearKey(providerId: String) {
        prefs.edit().remove(providerId).apply()
    }
}
